
-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `reservaciones`
--

DROP TABLE IF EXISTS `reservaciones`;
CREATE TABLE IF NOT EXISTS `reservaciones` (
  `ID_RESERVATION` int NOT NULL AUTO_INCREMENT,
  `ID_USERS` int DEFAULT NULL,
  `ID_ROOM` int DEFAULT NULL,
  `DATE_RESERV` date DEFAULT NULL,
  `DATE_IN` date DEFAULT NULL,
  `DATE_OUT` date DEFAULT NULL,
  `STATE_ROOM` varchar(20) DEFAULT NULL,
  `PAY_METHOD` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`ID_RESERVATION`),
  KEY `ID_USERS` (`ID_USERS`),
  KEY `ID_ROOM` (`ID_ROOM`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Truncar tablas antes de insertar `reservaciones`
--

TRUNCATE TABLE `reservaciones`;
--
-- Volcado de datos para la tabla `reservaciones`
--

INSERT INTO `reservaciones` (`ID_RESERVATION`, `ID_USERS`, `ID_ROOM`, `DATE_RESERV`, `DATE_IN`, `DATE_OUT`, `STATE_ROOM`, `PAY_METHOD`) VALUES
(1, 1, 101, '2024-08-20', '2024-08-25', '2024-08-30', 'Confirmada', 'Tarjeta de crédito'),
(2, 2, 102, '2024-08-21', '2024-08-27', '2024-09-01', 'Confirmada', 'PayPal'),
(3, 3, 103, '2024-08-22', '2024-08-28', '2024-08-31', 'Cancelada', 'Transferencia bancaria'),
(4, 4, 104, '2024-08-23', '2024-09-01', '2024-09-05', 'Confirmada', 'Efectivo'),
(5, 5, 105, '2024-08-24', '2024-09-03', '2024-09-07', 'Pendiente', 'Tarjeta de débito');
