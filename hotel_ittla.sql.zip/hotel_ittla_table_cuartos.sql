
-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `cuartos`
--

DROP TABLE IF EXISTS `cuartos`;
CREATE TABLE IF NOT EXISTS `cuartos` (
  `ID_ROOM` int NOT NULL AUTO_INCREMENT,
  `NUMBER_ROOM` varchar(10) NOT NULL,
  `TYPE` varchar(20) DEFAULT NULL,
  `PRICE_ROOM` decimal(10,2) DEFAULT NULL,
  `CAPACITY` int DEFAULT NULL,
  `STATE_ROOM` varchar(20) DEFAULT NULL,
  `ESPECS_ROOM` text,
  PRIMARY KEY (`ID_ROOM`),
  UNIQUE KEY `NUMBER_ROOM` (`NUMBER_ROOM`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Truncar tablas antes de insertar `cuartos`
--

TRUNCATE TABLE `cuartos`;
--
-- Volcado de datos para la tabla `cuartos`
--

INSERT INTO `cuartos` (`ID_ROOM`, `NUMBER_ROOM`, `TYPE`, `PRICE_ROOM`, `CAPACITY`, `STATE_ROOM`, `ESPECS_ROOM`) VALUES
(1, '101', 'Estándar', 50.00, 2, 'Ocupada', 'Vista al jardín, Aire acondicionado'),
(2, '102', 'Suite', 120.00, 4, 'Ocupada', 'Vista al mar, Jacuzzi, Mini bar'),
(3, '103', 'Doble', 80.00, 3, 'En limpieza', 'Vista a la piscina, TV por cable'),
(4, '104', 'Estándar', 55.00, 2, 'Disponible', 'Wi-Fi, Caja de seguridad'),
(5, '105', 'Suite Deluxe', 150.00, 5, 'Disponible', 'Balcón privado, Vista panorámica, Jacuzzi');
