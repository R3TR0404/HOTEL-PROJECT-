// Muestra un mensaje de bienvenida en la consola cuando la página carga
window.onload = function() {
    console.log('Bienvenido al sistema de gestión del Hotel Paradise');
};

// Interactividad del botón de "Reservar Ahora"
const reservarBtn = document.querySelector('.welcome-text button');

reservarBtn.addEventListener('click', function() {
    alert('¡Redirigiendo a la página de reservas!');
    // Aquí podrías redirigir a una página de reservas o ejecutar otra acción
    window.location.href = "#services"; // Ejemplo de redirección a la sección de servicios
});

// Cambiar el color del menú al hacer hover
const navLinks = document.querySelectorAll('nav ul li a');

navLinks.forEach(link => {
    link.addEventListener('mouseenter', () => {
        link.style.color = '#e67e22'; // Cambiar el color al pasar el mouse
    });
    
    link.addEventListener('mouseleave', () => {
        link.style.color = '#fff'; // Regresar al color original
    });
});

// Función de scroll suave para los enlaces de navegación
navLinks.forEach(link => {
    link.addEventListener('click', function(event) {
        event.preventDefault();
        const targetId = link.getAttribute('href');
        const targetSection = document.querySelector(targetId);
        targetSection.scrollIntoView({
            behavior: 'smooth'
        });
    });
});

// Mostrar y ocultar más detalles en la sección de servicios (ejemplo de interactividad)
const servicesList = document.querySelectorAll('#services ul li');

servicesList.forEach(service => {
    service.addEventListener('click', () => {
        alert(`Detalles del servicio: ${service.textContent}`);
    });
});
